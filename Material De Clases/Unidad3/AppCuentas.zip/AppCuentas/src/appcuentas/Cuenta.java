package appcuentas;

public interface Cuenta {
    final double SALDOMIN = 0.0;
    double getSaldo();
    double transferir(Cuenta destino, double monto);
    double depositar(double monto);    
}
