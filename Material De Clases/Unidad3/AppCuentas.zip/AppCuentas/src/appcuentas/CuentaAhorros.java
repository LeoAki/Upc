package appcuentas;

public class CuentaAhorros implements Cuenta{
    
    private double saldo;
    
    public CuentaAhorros(double saldo){
        this.saldo = saldo;        
    }

    public double depositar(double monto){
        saldo += monto;
        return saldo;
    }
    
    public double transferir(Cuenta cuenta, double monto){
        if (saldo > monto){
            saldo -= monto;
            cuenta.depositar(monto);
        }
        return saldo;
    }
        
    public double getSaldo(){
        return saldo;
    }
    
}
