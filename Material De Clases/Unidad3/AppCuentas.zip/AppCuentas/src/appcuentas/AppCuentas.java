package appcuentas;

public class AppCuentas {

    public static void main(String[] args) {
        Cuenta cuenta1;
        Cuenta cuenta2;
        Cuenta cuenta3;
        
        //Esto da error, por definicion una interfaz es abstracta
        //cuenta1 = new Cuenta(100.0);
        
        cuenta1 = new CuentaAhorros(100);
        cuenta2 = new CuentaAhorros(120);
        cuenta3 = new CuentaFija(150,6);
        
        System.out.println("Saldo Cuenta1 = " + cuenta1.getSaldo());
        System.out.println("Saldo Cuenta2 = " + cuenta2.getSaldo());
        System.out.println("Saldo Cuenta3 = " + cuenta3.getSaldo());
        
        System.out.println("Saldo cuenta1 luego de transferir 20 a la cuenta3 = " + cuenta1.transferir(cuenta3, 20));
        System.out.println("Saldo cuenta2 luego de depositar 50 = " + cuenta2.depositar(50));
        System.out.println("Saldo cuenta3 luego que recibió los 20 = " + cuenta3.getSaldo());
        
        //Métodos que heredan automáticamente todas las clases de Object:
        System.out.println("\nInforma la clase del objeto: " + cuenta3.getClass());
        System.out.println("Método que todo objeto tiene para describirse: " + cuenta3.toString());
    }
    
}
