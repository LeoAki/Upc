package appcuentas;

public class CuentaFija implements Cuenta{
    private double saldo;
    private int plazo;
    
    public CuentaFija(double saldo, int plazo){
        this.saldo = saldo;
        this.plazo = plazo;
    }
    
    public double depositar(double monto){
        saldo += monto;
        plazo--;
        return saldo;
    }
    
    public double transferir(Cuenta cuenta, double monto){
        if (saldo > monto){
            saldo -= monto;
            plazo++;
            cuenta.depositar(monto);
        }
        return saldo;
    }
        
    public double getSaldo(){
        return saldo;
    }
    
    public double getPlazo(){
        return plazo;
    }
}
