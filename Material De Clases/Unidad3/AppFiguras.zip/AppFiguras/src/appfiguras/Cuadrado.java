package appfiguras;

public class Cuadrado extends Figura{
    private int lado;
    
    public Cuadrado(String color, int x, int y, int lado){
        super(color, x, y);
        this.lado = lado;
    }
        
    @Override
    public double calcularArea(){
        return lado * lado;        
    }
    
    @Override
    public String imprimirDetalles(){
        return "Cuadrado de color " + color + " de lado " + lado;
    }        
    
}

