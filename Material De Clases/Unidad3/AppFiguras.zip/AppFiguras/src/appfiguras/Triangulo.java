package appfiguras;

public class Triangulo extends Figura{
    private int altura;
    private int base;
    
    public Triangulo(String color, int x, int y, int altura, int base){
        super(color, x, y);
        this.altura = altura;
        this.base = base;
    }
    
    @Override
    public double calcularArea(){
        return base * altura / 2;
    }
    
    @Override
    public String imprimirDetalles(){
        return "Triángulo de base " + base + " y altura " + altura;
    }
    
    /*Esto da error pues el método es final
    @Override
    public String imprimirFigura(){
        return "Triangulo";
    } */           
    
}

