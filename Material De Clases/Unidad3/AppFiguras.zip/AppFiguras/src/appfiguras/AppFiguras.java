package appfiguras;

public class AppFiguras {

    public static void main(String[] args) {
        
        Figura[] listaDeFiguras;
        listaDeFiguras= new Figura[3];
        
        //Esta sentencia da error, porque una clase abstracta no se puede instanciar
        //listaDeFiguras[0]= new Figura("azul", 1, 0);
        
        //Forma correcta:
        listaDeFiguras[0] = new Triangulo("azul", 1, 0, 3, 2);
        System.out.println(listaDeFiguras[0].imprimirFigura());
        System.out.println(listaDeFiguras[0].imprimirDetalles());
        
        listaDeFiguras[1] = new Cuadrado("rojo", 1, 1, 5);
        listaDeFiguras[2] = new Triangulo("amarillo", 3, 3, 2, 1);
        
        System.out.println("\nRecorrido del Array de Figuras:");
        
        for (int i = 0; i < 3; i++){            
            //Ejemplos de polimorfismo
            System.out.println(i + ". " + listaDeFiguras[i].imprimirDetalles());
            System.out.println("Área: " + listaDeFiguras[i].calcularArea());
        }    
    }    
}
