package appfiguras;

public abstract class Figura {
    protected String color;
    protected int x;
    protected int y;
    
    public Figura(String color, int x, int y){
        this.color = color;
        this.x = x;
        this.y = y;
    }
    
    final public String imprimirFigura(){
        return "Figura de color " + color + " que inicia en (" + x + ", " + y + ")";
    }
    
    abstract double calcularArea();
    abstract String imprimirDetalles();
}
