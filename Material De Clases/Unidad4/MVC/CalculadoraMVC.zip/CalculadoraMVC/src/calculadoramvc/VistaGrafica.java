package calculadoramvc;

import java.awt.*;
import javax.swing.*;

public class VistaGrafica extends JFrame{
    
    Container bloqueContenedor = null;
    JTextField txtNumero1 = null;
    JTextField txtNumero2 = null;
    JTextField txtResultado = null;
    JLabel lblNumero1 = null;
    JLabel lblNumero2 = null;
    JLabel lblResultado = null;
    JButton btnSumar = null;
    JButton btnRestar = null;
    
    public VistaGrafica(){
        bloqueContenedor = getContentPane();
        setTitle("Calculadora");
        setLayout(new FlowLayout());
        setSize(230, 200);

        lblNumero1 = new JLabel("Número 1: ");
        txtNumero1 = new JTextField("", 10);

        lblNumero2 = new JLabel("Número 2: ");
        txtNumero2 = new JTextField("", 10);

        lblResultado = new JLabel("Resultado: ");
        txtResultado = new JTextField("", 15);

        btnSumar = new JButton("Sumar");
        btnRestar = new JButton("Restar");

        bloqueContenedor.add(lblNumero1);
        bloqueContenedor.add(txtNumero1);
        bloqueContenedor.add(lblNumero2);
        bloqueContenedor.add(txtNumero2);
        bloqueContenedor.add(btnSumar);
        bloqueContenedor.add(btnRestar);
        bloqueContenedor.add(lblResultado);
        bloqueContenedor.add(txtResultado);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
}
