package calculadoramvc;

public class CalculadoraMVC {
    
    public static void main(String[] args) {
        
        Modelo modelo = new Modelo();
        
        /*VistaTexto vista = new VistaTexto();
        ControladorTexto controlador = new ControladorTexto(modelo, vista);*/
        
        
        VistaGrafica vista = new VistaGrafica();
        ControladorGrafico controlador = new ControladorGrafico(modelo, vista);
        
    }
    
}
