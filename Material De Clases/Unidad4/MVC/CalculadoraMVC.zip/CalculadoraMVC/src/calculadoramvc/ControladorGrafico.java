package calculadoramvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorGrafico implements ActionListener{
    private Modelo modelo = null;
    private VistaGrafica vista = null;
    
    public ControladorGrafico (Modelo modelo, VistaGrafica vista){
        this.modelo = modelo;
        this.vista = vista;
        actionListener(this); //para escuchar los botones
    }
    
    @Override
    public void actionPerformed(ActionEvent evento){
        try{
            String numero1 = this.vista.txtNumero1.getText();
            String numero2 = this.vista.txtNumero2.getText();
            int resultado = 0;
            if (vista.btnSumar == evento.getSource()){
            resultado = modelo.sumar(Integer.parseInt(numero1), Integer.parseInt(numero2));
            }
            if (vista.btnRestar == evento.getSource()){
            resultado = modelo.restar(Integer.parseInt(numero1), Integer.parseInt(numero2));
            }
            
            vista.txtResultado.setText("" + resultado);
        }
        catch(Exception excepcion){
            excepcion.printStackTrace();
        }
    }
    
    public void actionListener(ActionListener escuchador){
        vista.btnSumar.addActionListener(escuchador);
        vista.btnRestar.addActionListener(escuchador);
    }    
    
}
