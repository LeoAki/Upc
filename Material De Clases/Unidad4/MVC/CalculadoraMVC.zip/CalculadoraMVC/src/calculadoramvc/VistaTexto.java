package calculadoramvc;

public class VistaTexto {
    
    public void mostrarMenu(){
        System.out.println("\n*** Calculadora ***");
        System.out.println("[I]ngresar números");
        System.out.println("[S]Sumar");
        System.out.println("[R]estar");
        System.out.println("[F]inalizar");
        System.out.println("\n>>>Ingrese una opción: ");
    }
    
    public void ingresarNumero1(){
        System.out.println("\n>>> Ingresar primer número: ");        
    }
    
    public void ingresarNumero2(){
        System.out.println("\n>>> Ingresar primer número: ");        
    }
    
    public void imprimirResultado(int resultado){
        System.out.println(">>> El resultado es: " + resultado);
    }
    
    public void imprimirOpcionNoValida(){
        System.out.println(">>> Opción no válida");
    }
    
    public void noInicializados(){
        System.out.println(">>> Alguno de los números no ha sido inicializado, elegir opción [I]");
    }
    
    public void despedida(){
        System.out.println(">>> Adiós");
    }
    
}
