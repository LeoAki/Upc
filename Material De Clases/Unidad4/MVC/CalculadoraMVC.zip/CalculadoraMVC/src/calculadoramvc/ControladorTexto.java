package calculadoramvc;

import java.util.Scanner;

public class ControladorTexto {
    
    private Modelo modelo;
    private VistaTexto vista;
    Scanner entrada = new Scanner(System.in);
    
    public ControladorTexto (Modelo modelo, VistaTexto vista) {
        this.modelo = modelo;
        this.vista = vista;
        
        iniciarVista();
    }
    
    public void iniciarVista(){
        char opcion;
        boolean inicializados = false;
        String numero1 = null, numero2 = null;
        int resultado;
        
        do{
            vista.mostrarMenu();
            opcion = entrada.nextLine().toUpperCase().charAt(0);           
            
        
        
        switch (opcion) {            
            case 'I':
                vista.ingresarNumero1();
                numero1 = entrada.nextLine();
                vista.ingresarNumero2();
                numero2 = entrada.nextLine();
                inicializados = true;
                break;
            case 'S':
                if (inicializados){
                    resultado = modelo.sumar(Integer.parseInt(numero1), Integer.parseInt(numero2));
                    vista.imprimirResultado(resultado);
                } else {
                    vista.noInicializados();
                }                
                break;
            case 'R':
                if (inicializados){
                    resultado = modelo.restar(Integer.parseInt(numero1), Integer.parseInt(numero2));
                    vista.imprimirResultado(resultado);
                } else {
                    vista.noInicializados();
                }
                break;
            case 'F':
                vista.despedida();
                break;
            default:
                vista.imprimirOpcionNoValida();
                break;
        }
        } while (opcion != 'F');
    }
    
}
     
