package calculadoramvc;

public class Modelo {
    public int sumar(int numero1, int numero2){
        return numero1 + numero2;
    }
    
    public int restar(int numero1, int numero2){
        return numero1 - numero2;
    }
    
}
