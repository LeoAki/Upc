/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pooejemplo2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Julio
 */
public class EmpleadoTest {
    
    public EmpleadoTest() {
    }

    @Test
    public void testCalcularSueldo() {
        Empleado empleado1;
        double resultado;
               
        empleado1 = new Empleado("001", "Juan Perez", true, 900);
        resultado = empleado1.calcularSueldo(10);
        assertEquals(1200, resultado, 0.00);
        
    }
/*
    @Test
    public void testGetCodigo() {
    }

    @Test
    public void testSetCodigo() {
    }

    @Test
    public void testGetNombre() {
    }

    @Test
    public void testSetNombre() {
    }
*/
    @Test
    public void testIsPermanente() {
        Empleado empleado2;
        boolean resultado;
               
        empleado2 = new Empleado("002", "Jose Fernandez", true, 1000);
        assertTrue(empleado2.isPermanente());        
    }
/*
    @Test
    public void testSetPermanente() {
    }

    @Test
    public void testGetSueldobruto() {
    }

    @Test
    public void testSetSueldobruto() {
    }
*/    
}
