
package pooejemplo2;


public class Empleado {
    private String codigo;
    private String nombre;
    private boolean permanente;
    private double sueldobruto;
    final double COSTO_HORA_PERM = 30;
    final double COSTO_HORA_TEMP = 20;


    public Empleado(String codigo, String nombre, boolean permanente, double sueldobruto) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.permanente = permanente;
        this.sueldobruto = sueldobruto;       
        
    }
    
    public double calcularSueldo(int horasextras){
        if (this.permanente) {
            return this.sueldobruto + horasextras*this.COSTO_HORA_PERM;
        } else {
            return this.sueldobruto + horasextras*this.COSTO_HORA_TEMP;
        }
    }           

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isPermanente() {
        return permanente;
    }

    public void setPermanente(boolean permanente) {
        this.permanente = permanente;
    }

    public double getSueldobruto() {
        return sueldobruto;
    }

    public void setSueldobruto(double sueldobruto) {
        this.sueldobruto = sueldobruto;
    }
    
    
    
}
