
package pooejemplo2;


public class PooEjemplo2 {

    
    public static void main(String[] args) {
        Empleado empleado1;
        Empleado empleado2;
        
        empleado1 = new Empleado("001", "Juan Perez", true, 900);
        empleado2 = new Empleado("002", "Manuel Rodriguez", false, 750);
        
        System.out.print("Sueldo del empleado1, con 10 horas extra: ");
        System.out.println(empleado1.calcularSueldo(10));
        
        System.out.print("Sueldo del empleado2, con 5 horas extra: ");
        System.out.println(empleado2.calcularSueldo(5));       
        
    
    }
    
}
