package appanimales;

public class AppAnimales {

    public static void main(String[] args) {
        
        Animal animal;
        
        animal = new Animal("blanco", "Tornado", 1);
        System.out.println("Animal");
        System.out.println(animal.imprimir());
        System.out.println(animal.emitirSonido());
        System.out.println(animal.getNombre());
        
        Perro perro;
        perro = new Perro("marrón", "Fido", 2, "corto");
        System.out.println("\nPerro");
        System.out.println(perro.imprimir());
        System.out.println(perro.emitirSonido());
        System.out.println(perro.getNombre());
        
        Pez pez;
        pez = new Pez("gris", "Dora", 1, "de río");
        System.out.println("\nPez");
        System.out.println(pez.imprimir());
        System.out.println(pez.emitirSonido());
        System.out.println(pez.getNombre());
               
    }
    
}
