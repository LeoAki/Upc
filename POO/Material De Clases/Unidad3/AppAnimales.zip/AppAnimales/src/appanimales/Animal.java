package appanimales;


public class Animal {
    protected String color;
    protected String nombre;
    protected int edad;
    
    public Animal()
    {
        color = "No definido";
        nombre = "NN";
        edad = 0;
    }
    
    public Animal(String color, String nombre, int edad){
        this.color = color;
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public String imprimir(){
        return "Nombre: " + nombre + ", de color: " + color + ", edad: " + edad; 
    }
    
    public String emitirSonido(){
        return "Sin sonido definido";
    }

    public String getColor() {
        return color;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    } 
    
            
}
