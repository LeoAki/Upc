package appanimales;

public class Perro extends Animal{
    private String pelaje; //puede ser corto, largo
    
    public Perro(){
        this.pelaje = "Corto";
    }
    
    public Perro(String color, String nombre, int edad, String pelaje){
        super(color, nombre, edad);
        this.pelaje = pelaje;
    }

    public String getPelaje() {
        return pelaje;
    }

    public void setPelaje(String pelaje) {
        this.pelaje = pelaje;
    }
       
    @Override
    public String imprimir(){
        return "Perro: " + super.imprimir() + ", pelaje: " + pelaje;
    }
    
    @Override
    public String emitirSonido(){
        return "Guau Guau";
    }
}
