package appanimales;


public class Pez extends Animal {
    private String tipo; //De río, de mar
    
    public Pez(String color, String nombre, int edad, String tipo){
        super(color, nombre, edad);
        this.tipo = tipo;
    }
    
    @Override
    public String imprimir(){
        return "Pez: " + super.imprimir() + ", tipo: " + tipo;
    }
    
}
