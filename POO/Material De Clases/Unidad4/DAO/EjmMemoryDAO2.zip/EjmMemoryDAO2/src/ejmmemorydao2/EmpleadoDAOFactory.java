package ejmmemorydao2;

//Paso 5
//Implementación de Factory
public class EmpleadoDAOFactory {
    
    public static EmpleadoDAO crearEmpleadoDAO(){
        return new EmpleadoDAOMemoryImpl();
        //Encapsula el EmpleadoDAOMemoryImplement
    }
}
