package ejmmemorydao1;

//paso 2
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAOMemoryImpl implements EmpleadoDAO{
    
    private static Empleado[] empleadoArray = new Empleado[10];
    //static porque es variable de la clase, no depende de ninguna instancia

    @Override
    public void add(Empleado emp) {
        empleadoArray[emp.getId()] = emp;
    }

    @Override
    public void update(Empleado emp) {
        empleadoArray[emp.getId()] = emp;
    }

    @Override
    public void delete(int id) {
        empleadoArray[id] = null;
    }

    @Override
    public Empleado findById(int id) {
        return empleadoArray[id];
    }

    @Override
    public Empleado[] getAllEmpleados() {
        List<Empleado> emps = new ArrayList<>();
        for (Empleado e: empleadoArray){
            if (e != null){
                emps.add(e);
            }                
        }
        return emps.toArray(new Empleado[0]); //retorna empleados como Array        
    }
    
    
    
}
