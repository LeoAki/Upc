package ejmmemorydao1;

//primer paso
public interface EmpleadoDAO {
    
    public void add(Empleado emp);
    public void update(Empleado emp);
    public void delete(int id);
    public Empleado findById(int id);
    public Empleado[] getAllEmpleados();
    
}
