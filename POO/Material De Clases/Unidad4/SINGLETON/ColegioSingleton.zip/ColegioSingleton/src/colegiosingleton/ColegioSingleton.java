package colegiosingleton;

public class ColegioSingleton {

    public static void main(String[] args) {
        
        Alumno alumno1 = new Alumno("Juan Perez", 4, 'C');
        Alumno alumno2 = new Alumno("Jose Fernandez", 3, 'A');
        Alumno alumno3 = new Alumno("Manuel Rodriguez", 3, 'A');
        
        //4. Ya no se puede hacer esto después de aplicar Singleton
        //Colegio colegio1 = new Colegio("San Juan Bautista");
        //Colegio colegio2 = new Colegio("San Juan Bautista");
        
        Colegio colegio1 = Colegio.getInstance("San Juan Bautista");
        Colegio colegio2 = Colegio.getInstance("San Juan Bautista");
        //tanto colegio1 como colegio2 apuntan al mismo objeto, instancia única
        
        colegio1.agregarAlumno(alumno1);
        colegio1.agregarAlumno(alumno2);
        colegio2.agregarAlumno(alumno3);
        
        System.out.println("Colegio 1: " + colegio1.getNombre());
        for (Alumno a:colegio1.getAlumnos()){
            System.out.println(a.getNombreApellidos() + " " + a.getGrado() + " " + a.getSeccion());
        }
        
        System.out.println("\nColegio 2:" + colegio2.getNombre());
        for (Alumno a:colegio2.getAlumnos()){
            System.out.println(a.getNombreApellidos() + " " + a.getGrado() + " " + a.getSeccion());
        }
        
    }
    
}
