package colegiosingleton;

public class Alumno {
    
    private String nombreApellidos;
    private int grado;
    private char seccion;

    public Alumno(String nombreApellidos, int grado, char seccion) {
        this.nombreApellidos = nombreApellidos;
        this.grado = grado;
        this.seccion = seccion;
    }

    public String getNombreApellidos() {
        return nombreApellidos;
    }

    public void setNombreApellidos(String nombreApellidos) {
        this.nombreApellidos = nombreApellidos;
    }

    public int getGrado() {
        return grado;
    }

    public void setGrado(int grado) {
        this.grado = grado;
    }

    public char getSeccion() {
        return seccion;
    }

    public void setSeccion(char seccion) {
        this.seccion = seccion;
    }
    
    
}
