package colegiosingleton;

import java.util.ArrayList;
import java.util.List;

public class Colegio {
    //1. agregamos este atributo, que se llama instance por convención
    private static Colegio instance;
    
    private String nombre;
    private List<Alumno> alumnos;

    //public Colegio(String nombre) {
    //2. se cambia la visibilidad del contructor a private
    private Colegio(String nombre){
        this.nombre = nombre;
        alumnos = new ArrayList<>();
    }
    
    //3. Agregar método public static para crear u obtener instancia
    public static Colegio getInstance(String nombre){
        if(instance == null){
             instance = new Colegio(nombre);             
        }
        return instance;
    }
    
    public void agregarAlumno(Alumno alumno){
        alumnos.add(alumno);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Alumno> getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(List<Alumno> alumnos) {
        this.alumnos = alumnos;
    }
    
    
    
    
}
