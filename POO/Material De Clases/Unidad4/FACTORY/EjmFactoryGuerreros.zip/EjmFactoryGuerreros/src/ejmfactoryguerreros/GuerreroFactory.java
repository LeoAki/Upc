
package ejmfactoryguerreros;

public class GuerreroFactory {
    
    public static Guerrero crearGuerrero(String tipo){
        if (tipo.equalsIgnoreCase("Ninja")){
            return new Ninja();
        }
        if (tipo.equalsIgnoreCase("Samurai")){
            return new Samurai();
        }
        if (tipo.equalsIgnoreCase("TortugaNinja")){
            return new TortugaNinja();
        }
        return null;
    }
    
}
