package ejmfactoryguerreros;

public class Samurai implements Guerrero {
    
    private String grito;
    private int potenciaAtaque;
    
    public Samurai(){
        grito = "Yaaaahhhh!";
        potenciaAtaque = 50;
    }

    @Override
    public String getGritoDeGuerra() {
        return grito;
    }

    @Override
    public int getPotenciaDeAtaque() {
        return potenciaAtaque;
    }

    @Override
    public String imprimirGuerrero() {
        return "Soy un Samurai " + grito;
    }
    
    
}
