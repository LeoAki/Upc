package ejmfactoryguerreros;

public interface Guerrero {
    String getGritoDeGuerra();
    int getPotenciaDeAtaque();
    String imprimirGuerrero();
}
