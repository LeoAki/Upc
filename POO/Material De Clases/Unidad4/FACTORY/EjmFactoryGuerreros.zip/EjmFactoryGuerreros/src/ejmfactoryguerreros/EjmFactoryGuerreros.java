package ejmfactoryguerreros;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class EjmFactoryGuerreros {

    public static void main(String[] args) throws IOException {
        List<Guerrero> misGuerreros = new ArrayList<>();
        char opcion;
        
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        
        do{
            System.out.println("\nCreación de guerreros");
            System.out.println("¿Que tipo de Guerrero deseas?");
            System.out.println("[N]inja, [S]amurai, [T]ortugaNinja, [Q]uit");
            System.out.println("Opción: ");
            opcion = entrada.readLine().toUpperCase().charAt(0);
            
            switch(opcion){
                case 'N':
                    misGuerreros.add(GuerreroFactory.crearGuerrero("Ninja"));
                    System.out.println("Ninja creado");
                    break;
                case 'S':
                    misGuerreros.add(GuerreroFactory.crearGuerrero("Samurai"));
                    System.out.println("Samurai creado");
                    break;
                case 'T':
                    misGuerreros.add(GuerreroFactory.crearGuerrero("TortugaNinja"));
                    System.out.println("TortuNinja creado");
                    break;    
            }
        } while (opcion == 'N' || opcion == 'S' || opcion == 'T');
        
        System.out.println("\nMis Guerreros creados:");
        for (Guerrero g: misGuerreros){
            System.out.println(g.imprimirGuerrero());
        }
    }
    
}
