package ejmfactoryguerreros;

public class TortugaNinja extends Ninja{
    private String grito;
    private int potenciaAtaque;
    
    public TortugaNinja() {
        grito = super.getGritoDeGuerra() + ", TortuNinja Rap!";
        potenciaAtaque = super.getPotenciaDeAtaque() + 20;
    }
    
    @Override
    public String imprimirGuerrero() {
        return "Soy un Ninja " + grito;
    }
    
}
