package ejmfactoryguerreros;

public class Ninja implements Guerrero {
    private String grito;
    private int potenciaAtaque;
    
    public Ninja() {
        grito = "Aaahhhhh!";
        potenciaAtaque = 60;                
    }

    @Override
    public String getGritoDeGuerra() {
        return grito;
    }

    @Override
    public int getPotenciaDeAtaque() {
        return potenciaAtaque;
    }

    @Override
    public String imprimirGuerrero() {
        return "Soy un Ninja " + grito;
    }
    
}
