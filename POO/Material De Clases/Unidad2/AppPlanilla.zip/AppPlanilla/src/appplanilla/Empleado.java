
package appplanilla;

import java.util.Calendar;
import java.util.GregorianCalendar;


public class Empleado {
    private String dni;
    private String nombre;
    private boolean tipo;
    private int anhoNacimiento;

    public Empleado(String dni, String nombre, boolean tipo, int anhoNacimiento) {
        this.dni = dni;
        this.nombre = nombre;
        this.tipo = tipo;
        this.anhoNacimiento = anhoNacimiento;
    }

    public int calcularAnhos() {
        Calendar c = new GregorianCalendar();
        return c.get(Calendar.YEAR) - this.anhoNacimiento;        
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isTipo() {
        return tipo;
    }

    public void setTipo(boolean tipo) {
        this.tipo = tipo;
    }

    public int getAnhoNacimiento() {
        return anhoNacimiento;
    }

    public void setAnhoNacimiento(int anhoNacimiento) {
        this.anhoNacimiento = anhoNacimiento;
    }
    
    
    
}
