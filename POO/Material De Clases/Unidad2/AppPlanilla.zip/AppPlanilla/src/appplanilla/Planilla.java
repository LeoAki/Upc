
package appplanilla;

import java.util.ArrayList;

public class Planilla {
    private String mes;
    private int anho;
    private ArrayList <Empleado> empleados;

    public Planilla(String mes, int anho) {
        this.mes = mes;
        this.anho = anho;
        this.empleados = new ArrayList <Empleado>();
    }

    public void agregarEmpleado(Empleado empleado1) {
        empleados.add(empleado1);
    }

    public double calcularGastoTotal() {
        double gastoTotal = 0.0;
        for(Empleado e:empleados){
            if(e.isTipo())
                gastoTotal += 1000;
            else
                gastoTotal += 750;
        }
        return gastoTotal;
    }    
}
