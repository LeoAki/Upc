
import appplanilla.Empleado;
import appplanilla.Planilla;
import org.junit.Test;
import static org.junit.Assert.*;


public class TestPlanilla {
    
    public TestPlanilla() {
    }
    
    @Test
    public void testCalcularGastoTotal() {
        Empleado empleado1, empleado2, empleado3;
        empleado1 =  new Empleado("12121212", "Juan Perez", true, 1965);
        empleado2 =  new Empleado("52121215", "Jose Fernandez", false, 1975);
        empleado3 =  new Empleado("62121216", "Miguel Benitez", true, 1985);
        
        Planilla planilla1;
        planilla1 = new Planilla("Ene", 2015);
        
        planilla1.agregarEmpleado(empleado1);
        planilla1.agregarEmpleado(empleado2);
        planilla1.agregarEmpleado(empleado3);
        
        double resultadoEsperado = 2750.0;
        double resultadoActual = planilla1.calcularGastoTotal();
        assertEquals(resultadoEsperado, resultadoActual, 0.00);   
                
        
    }
    
}
