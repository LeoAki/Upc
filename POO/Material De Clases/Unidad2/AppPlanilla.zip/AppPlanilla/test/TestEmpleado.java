
import appplanilla.Empleado;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestEmpleado {
    
    public TestEmpleado() {
    }
    
    @Test
    public void testCalcularAnhos() {
        Empleado empleado;
        empleado = new Empleado("12345678", "Juan Perez", true, 1965);
        int resultadoEsperado = 50;
        int resultadoActual = empleado.calcularAnhos();
        assertEquals(resultadoEsperado, resultadoActual);
    }   
    
    
}
