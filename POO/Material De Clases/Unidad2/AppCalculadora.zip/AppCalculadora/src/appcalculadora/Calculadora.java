
package appcalculadora;

public class Calculadora {

    public Calculadora() {
    }   
    
    public int sumar(int a, int b) {
        return a + b;        
    }

    public int restar(int a, int b) {
        return a - b;
    }

    public int resto(int a, int b) {
        return a % b;        
    }
    
}
