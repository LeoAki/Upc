import appcalculadora.Calculadora;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class TestCalculadora {
    
    public TestCalculadora() {
    }   
   
    
    @Test
    public void testSumar() {
        Calculadora calculadora = new Calculadora();
        int resultadoEsperado = 7;
        int resultadoActual = calculadora.sumar(5, 2);
        assertEquals(resultadoEsperado, resultadoActual);
    }    
    
    @Test
    public void testRestar() {
        Calculadora calculadora = new Calculadora();
        int resultadoEsperado = 4;
        int resultadoActual = calculadora.restar(10, 6);
        assertEquals(resultadoEsperado, resultadoActual);
    }    
        
    @Test
    public void testResto() {
        Calculadora calculadora = new Calculadora();
        int resultadoEsperado = 2;
        int resultadoActual = calculadora.resto(14, 3);
        assertEquals(resultadoEsperado, resultadoActual);
    }
}
