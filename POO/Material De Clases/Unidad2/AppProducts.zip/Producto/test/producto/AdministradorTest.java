/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package producto;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author CFlores
 */
public class AdministradorTest {
    
    public AdministradorTest() {
    }

    @Test
    public void obtenerSuma()
    {
        Producto producto1 = new Producto("001", "Microprocesador i5", 240.00);
        Producto producto2 = new Producto("002", "Mouse Logitech", 60.00);
        Administrador administrador = new Administrador();
        administrador.adicionar(producto1);
        administrador.adicionar(producto2);
        double resultado;
        resultado = administrador.sumarPrecios();
        assertEquals(producto1.getPrecio() + producto2.getPrecio(), resultado, 0.00);
    }
    
}
