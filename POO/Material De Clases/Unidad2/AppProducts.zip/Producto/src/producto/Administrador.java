/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package producto;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author CFlores
 */
public class Administrador {
    private List<Producto> catalogo = new ArrayList<Producto>();
    
    public double sumarPrecios(){
        double suma = 0;
        for(Producto p:catalogo){
            suma+=p.getPrecio();
        }
        return suma;
    }
    public void adicionar(Producto producto){
        this.catalogo.add(producto);
    }
    public List<Producto> getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(List<Producto> catalogo) {
        this.catalogo = catalogo;
    }  
    
}
