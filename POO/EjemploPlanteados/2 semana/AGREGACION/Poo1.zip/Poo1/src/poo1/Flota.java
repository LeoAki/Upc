/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo1;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Julio
 */
public class Flota {
    private ArrayList <Auto> flota;
    
    Flota () {
        this.flota = new ArrayList <Auto>();
    }
    
    public void agregarAuto(Auto auto){
        this.flota.add(auto);   
    }
    
    public void imprimirFlota(){
        Iterator <Auto> it = this.flota.iterator();
        while (it.hasNext()){
            Auto a = it.next();
            a.imprimirAuto();
        }
    }
    
    public void aumentarVelocidad(int v){
        Iterator <Auto> it = this.flota.iterator();
        while (it.hasNext()){
            Auto a = it.next();
            a.setVelocidad(a.getVelocidad()+v);
        }
    }
}
