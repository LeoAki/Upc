
package poo2;

import java.util.HashSet;
import java.util.Set;

public class Poo2 {
 
    public static void main(String[] args) {
        Auto a1;
        Auto a2;
        Placa p1;
        Placa p2;
        
        a1 = new Auto(4, 80, "Negro");
        a1.imprimirAuto();
        
        p1 = a1.getPlaca();
        p1.setPlaca("AAA-123");
                
        System.out.println("\nDespués de actualizar la placa");
        a1.imprimirAuto();
        
        a2 = new Auto(4, 80, "Negro");
        a2.imprimirAuto();
        p2 = a2.getPlaca();
        System.out.println("Placa de auto 2: " + p2.getPlaca());
        a2 = null;
        //Debe dar error:
        //p2 = a2.getPlaca();
        //al eliminar el auto se elimina también la placa        
    }
    
}
