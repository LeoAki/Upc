
package poo2;


public class Placa {
    
    String placa;
    String tipo;
    
    public Placa(){
        this.placa = "En trámite";
        this.tipo = "Particular";
    }
    
    void imprimirPlaca() {
        System.out.println("Placa: " + this.getPlaca() + " de tipo " + this.getTipo());
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
}
