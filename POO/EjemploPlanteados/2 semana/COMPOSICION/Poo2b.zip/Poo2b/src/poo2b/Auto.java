/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo2b;

/**
 *
 * @author Julio
 */
public class Auto {
    private int numero_puertas;
    private int velocidad;
    private String color;
    private Placa placa;
    
    public Auto(int numero_puertas, int velocidad, String color) {
        this.numero_puertas = numero_puertas;
        this.velocidad = velocidad;
        this.color = color;
        this.placa = new Placa();
    }
    
    public void imprimirAuto() {
        System.out.println("\nDatos de auto:" );
        System.out.println("Placa: " + this.placa.getNumeroPlaca() + ", Tipo: " + this.placa.getTipo());
        System.out.println("Puertas: " + this.getNumero_puertas() + ", Velocidad: " + this.getVelocidad() + ", Color" + this.getColor());        
    }
    
    public int getNumero_puertas() {
        return numero_puertas;
    }

    public void setNumero_puertas(int numero_puertas) {
        this.numero_puertas = numero_puertas;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Placa getPlaca() {
        return placa;
    }

    //Esta es otra forma de actualizar la Placa, con un método en la clase Auto
    public void actualizarPlaca(String numeroplaca, String tipo) {
        this.placa.setNumeroPlaca(numeroplaca);
        this.placa.setTipo(tipo);  
    
    }
    
    public String informaNumeroPlaca() {
        return this.placa.getNumeroPlaca();
    }
    
}
