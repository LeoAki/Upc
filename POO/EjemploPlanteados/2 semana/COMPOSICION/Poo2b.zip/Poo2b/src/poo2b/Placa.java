
package poo2b;

public class Placa {
    String numeroplaca;
    String tipo;
    
    public Placa(){
        this.numeroplaca = "En trámite";
        this.tipo = "Particular";
    }
    
    void imprimirPlaca() {
        System.out.println("Placa: " + this.getNumeroPlaca() + " de tipo " + this.getTipo());
    }

    public String getNumeroPlaca() {
        return numeroplaca;
    }

    public void setNumeroPlaca(String numeroplaca) {
        this.numeroplaca = numeroplaca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
}
