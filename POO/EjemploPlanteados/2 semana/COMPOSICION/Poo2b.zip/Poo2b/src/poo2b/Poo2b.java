
package poo2b;

public class Poo2b {

    public static void main(String[] args) {
        Auto a1;
        Auto a2;
        Placa p2;
        
        a1 = new Auto(4, 80, "Negro");
        a1.imprimirAuto();
        
        a1.actualizarPlaca("AAA-123", "Militar");
                
        System.out.println("\nDespués de actualizar la placa");
        a1.imprimirAuto();
        
        a2 = new Auto(4, 80, "Negro");
        a2.imprimirAuto();
        //a2 creó una placa, obtenemos la información
        System.out.println("Placa de auto 2: " + a2.informaNumeroPlaca());
        a2 = null; //Elimina el objeto a2, y también la placa que contiene
        
        //Las siguientes sentencias darían error, pues al destruir a2 la placa de ese auto se destruye
        //p2 = a2.getPlaca();
        //System.out.println("Placa de auto 2: " + a2.informaNumeroPlaca());
    }    
}
