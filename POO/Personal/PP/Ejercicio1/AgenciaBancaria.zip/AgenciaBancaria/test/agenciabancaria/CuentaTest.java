
package agenciabancaria;

import org.junit.Test;
import static org.junit.Assert.*;


public class CuentaTest {
    //Sólo se va a realizar test de la operación transferir
    /*
    public CuentaTest() {
    }

    @Test
    public void testGetNumero() {
    }

    @Test
    public void testSetNumero() {
    }

    @Test
    public void testGetTipo() {
    }

    @Test
    public void testSetTipo() {
    }

    @Test
    public void testGetSaldo() {
    }

    @Test
    public void testSetSaldo() {
    }

    @Test
    public void testDepositar() {
    }

    @Test
    public void testRetirar() {
    }
    */
    
    @Test
    public void testTransferir() {
        Cuenta c1, c2;
        double resultado1, resultado2;
        
        c1 = new Cuenta("S0003", "Soles", 500);
        c2 = new Cuenta("S0004", "Soles", 200);
        resultado1 = c1.transferir(100, c2);  //la cuenta c1 debería quedar con 400
        assertEquals(400,resultado1,0.0);
    
        resultado2 = c2.getSaldo();  //la cuenta c2 debería quedar con 300
        assertEquals(300,resultado2,0.0);
        
    }
    
}
