
package agenciabancaria;

public class Cuenta {
    private String numero; //es String porque inicia con la letra S o D
    private String tipo;
    private double saldo;

    public Cuenta(String numero, String tipo, double saldo) {
        this.numero = numero;
        this.tipo = tipo;
        this.saldo = saldo;        
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
        
    public double depositar(double monto){
        this.saldo = this.saldo + monto;
        return this.saldo;
    }
    
    public double retirar(double monto){
        if (monto < this.saldo){
            this.saldo = this.saldo - monto;
            return this.saldo;
        } else {
            return -1; //indica error: saldo insuficiente
        }
    }
    
    public double transferir(double monto, Cuenta cuenta_destino){
        if (monto < this.saldo){
            cuenta_destino.depositar(monto);
            this.saldo = this.saldo - monto;
            return this.saldo;
        } else {
            return -1; //indica error: saldo insuficiente
        }
    }
    
    
            
    
    
    
}
