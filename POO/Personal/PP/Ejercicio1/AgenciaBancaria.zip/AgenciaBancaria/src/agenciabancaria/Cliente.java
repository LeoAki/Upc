
package agenciabancaria;

import java.util.ArrayList;

public class Cliente {
    private String DNI;
    private String nombre;
    private String apellido;
    private ArrayList <Cuenta> cuentas;

    public Cliente(String DNI, String nombre, String apellido) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuentas = new ArrayList <Cuenta>(); 
    }
    
    public void abrirCuenta(String numero, String tipo, double monto){
        Cuenta cuenta;
        cuenta = new Cuenta(numero, tipo, monto);
        this.cuentas.add(cuenta);
    }
        
    public Cuenta obtenerCuenta(String numero){    
        Cuenta cuenta = null;
        for (Cuenta c:cuentas){  //Recorre las cuentas del cliente
            if (c.getNumero().equals(numero)){ //si encuentra el numero de cuenta
                cuenta = c;
            }
        }
        return cuenta;
    }
    
    public void emitirEstadoCuenta(){
        System.out.println("\nCliente: " + this.nombre + " " + this.apellido);
        for (Cuenta c:cuentas){
            System.out.print("Cuenta número: " + c.getNumero() + " * Tipo: " + c.getTipo());
            System.out.println(" * Saldo a la fecha: " + c.getSaldo());
    }           
    }   
    
}
