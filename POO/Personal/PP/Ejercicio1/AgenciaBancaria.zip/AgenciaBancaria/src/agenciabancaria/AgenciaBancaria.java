
package agenciabancaria;

import java.util.ArrayList;

public class AgenciaBancaria {

    public static void main(String[] args) {
        Cliente c1, c2;
        
        
        //Creación de primer cliente
        c1 = new Cliente("23423454", "Juan", "Perez");
        
        //Abrir dos cuentas para Juan Perez
        c1.abrirCuenta("S0001", "Soles", 500);
        c1.abrirCuenta("D0001", "Dolares", 200);
        
        //Creación de segundo cliente
        c2 = new Cliente("12345678", "Manuel", "Fernandez");
        
        //Abrir una cuenta para Manuel Fernandez
        c2.abrirCuenta("S0002", "Soles", 100);
        
        //impresión de ambos estados de cuenta
        System.out.println("Estados de cuentas antes de movimientos");
        c1.emitirEstadoCuenta();
        c2.emitirEstadoCuenta();
        
        //Realizar un retiro de 50 dolares en la cuenta D0001.
        c1.obtenerCuenta("D0001").retirar(50);
                 
        //Realizar un depósito de 100 soles en la cuenta S0001.
        c1.obtenerCuenta("S0001").depositar(100);
                
        //Realizar una transferencia de la S0001 a la cuenta S0002 de 200 soles.
        c1.obtenerCuenta("S0001").transferir(200, c2.obtenerCuenta("S0002"));
        
        //Imprima por pantalla nuevamente los estados de cuentas para ambos clientes.
        System.out.println("\nEstados de cuentas luego de movimientos");
        c1.emitirEstadoCuenta(); 
        c2.emitirEstadoCuenta();
           
        
        
    }
    
}
