package appgestion;

public class Estudiante extends Asistente{
    private String universidad;
    private String carrera;
    private int anio;

    public Estudiante(String universidad, String carrera, int anio, String dni, String apellido, String nombre) {
        super(dni, apellido, nombre);
        this.universidad = universidad;
        this.carrera = carrera;
        this.anio = anio;
    }
    
    @Override
    public double calcularCuota(){
        double cuota = 200;
        if(anio == 4 || anio == 5){
            cuota = 150;
        }
        return cuota;
    }
    
    @Override
    public String printDet(){
        return "Estudiante en la universidad " + universidad + " en la carrera de " + carrera + ", cruzando el " + anio + " año academico.";
    } 
    
}
