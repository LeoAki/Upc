package appgestion;

public class Investigador extends Asistente {
    private String grado;
    private String area;

    public Investigador(String grado, String area, String dni, String apellido, String nombre) {
        super(dni, apellido, nombre);
        this.grado = grado;
        this.area = area;
    }
    
    @Override
    public double calcularCuota(){
        double cuota = 100;
        if(area.equals("Ing.deSistemas")){
            cuota = 0;
        }
        return cuota;
    }
    
    @Override
    public String printDet(){
        return "Investigador con grado de " + grado + " en el área de " + area + ".";
    } 
}
