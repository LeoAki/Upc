package appgestion;

import java.util.ArrayList;
import java.util.Iterator;

public class Congreso {
    private ArrayList <Asistente> congreso;

    Congreso() {
        this.congreso = new ArrayList<Asistente>();
    }

    public void addAsistente(Asistente asist){
        this.congreso.add(asist);   
    }
    
    public int totalAsistentes(){
        return congreso.size();
    }
    
    public void detallarCongreso(){
        int i = 1;
        Iterator<Asistente> asistente = congreso.iterator();
        while (asistente.hasNext()){
            Asistente asist = asistente.next();
            System.out.println("   " + i + ". " + asist.printAsistente());
            System.out.println("      " + asist.printDet());
            System.out.println("      Monto de inscripcion a pagar : S/. " + asist.calcularCuota());
            i += 1;
        }
    }
    
    public double totalRecaudado(){
        double total = 0.0;
        Iterator<Asistente> asistente = congreso.iterator();
        while (asistente.hasNext()){
            Asistente asist = asistente.next();
            total += asist.calcularCuota();
        }
        return total;
    }
    
    public void detallarAsistente(String dni){
        Iterator<Asistente> asistente = congreso.iterator();
        while (asistente.hasNext()){
            Asistente asist = asistente.next();
            if(dni.equals(asist.dni)){
                System.out.println("\n   " + asist.printAsistente());
                System.out.println("   " + asist.printDet());
                System.out.println("   Monto de inscripcion a pagar : S/. " + asist.calcularCuota());
                break;
            }            
        }
    }

}
