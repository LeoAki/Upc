package appgestion;

public class Profesional extends Asistente {
    private String grado;
    private String profesion;

    public Profesional(String grado, String profesion, String dni, String apellido, String nombre) {
        super(dni, apellido, nombre);
        this.grado = grado;
        this.profesion = profesion;
    }
    
    @Override
    public double calcularCuota(){
        double cuota = 250;
        if(grado.equals("Magister") || grado.equals("Doctor")){
            cuota = 200;
        }
        return cuota;
    }
    
    @Override
    public String printDet(){
        return "Profesional " + grado + " en " + profesion + ".";
    } 
}
