package appgestion;

public abstract class Asistente {
    protected String dni;
    protected String apellido;
    protected String nombre;

    public Asistente(String dni, String apellido, String nombre) {
        this.dni = dni;
        this.apellido = apellido;
        this.nombre = nombre;
    }
    
    final public String printAsistente(){
        return "Asistente : " + apellido + ", " + nombre + " con DNI " + dni;        
    }
    
    abstract double calcularCuota();
    abstract String printDet();
    
}
