package appgestion;

import java.util.Scanner;

public class AppGestion {

    public static void main(String[] args) {
        
        Asistente asist1 = new Estudiante("UNMSM","Marketing",2,"12345678", "Perez", "Juan"); 
        Asistente asist2 = new Estudiante("UNFV","Contabilidad",4,"23456789", "Perez", "Juan");
        Asistente asist3 = new Profesional("Titulado","Educacion","34567890", "Santos", "Juan");
        Asistente asist4 = new Profesional("Doctor","Medicina","87654321", "Ramirez", "Pedro");
        Asistente asist5 = new Investigador("Magister","Ing.DeSistemas","98765432", "Fernandez", "Andres");
        
        Congreso congreso = new Congreso();
        
        congreso.addAsistente(asist1);
        congreso.addAsistente(asist2);
        congreso.addAsistente(asist3);
        congreso.addAsistente(asist4);
        congreso.addAsistente(asist5);
        
        System.out.println("*DETALLE PARA ADMINISTRADOR*\n");        
        System.out.println(" - Total de asistentes registrados : " + congreso.totalAsistentes());
        System.out.println("\n - Detalle de Asistentes:");
        congreso.detallarCongreso(); 
        System.out.println("\n - Monto total recaudado por inscripciones : S/. " + congreso.totalRecaudado());
        System.out.println("\n - Monto pagado por asistente:");
        
        System.out.print("   Ingresar DNI : ");
        Scanner entradaEscaner = new Scanner (System.in);
        String dni = entradaEscaner.nextLine ();
        
        congreso.detallarAsistente(dni);
    }
    
}
