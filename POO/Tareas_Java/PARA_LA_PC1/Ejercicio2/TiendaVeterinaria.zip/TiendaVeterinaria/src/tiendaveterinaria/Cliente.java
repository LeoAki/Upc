
package tiendaveterinaria;

public class Cliente {
    private String dni;
    private String nombre;
    private String apellido;
    private Mascota mascota;

    public Cliente(String dni, String nombre, String apellido) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }
    
    public String imprimirCliente(){
        return nombre + " " + apellido + " con DNI: " + dni;
    }
    
}
