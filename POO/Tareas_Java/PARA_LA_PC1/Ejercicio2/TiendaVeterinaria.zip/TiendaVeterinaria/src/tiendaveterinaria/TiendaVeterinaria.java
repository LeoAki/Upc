
package tiendaveterinaria;

import java.util.HashSet;

public class TiendaVeterinaria {

    public static void main(String[] args) {
        Mascota mascota1 = new Mascota("Fido", "Perro", 'm');
        Cliente cliente1 = new Cliente("12345678", "Juan", "Perez");
        cliente1.setMascota(mascota1);
        
        Mascota mascota2 = new Mascota("Michi", "Gato", 'p');
        Cliente cliente2 = new Cliente("21436587", "Pedro", "Fernandez");
        cliente2.setMascota(mascota2);
        
        System.out.println("Detalles de Servicios:");
        
        Servicio servicio1 = new Servicio("LU0001", 9, "Lu");
        servicio1.setCliente(cliente1);
        System.out.println(servicio1.reportarPago());        
        
        Servicio servicio2 = new Servicio("LU0002", 16, "Lu");
        servicio2.setCliente(cliente2);        
        System.out.println(servicio2.reportarPago());
                
        Servicio servicio3 = new Servicio("SA0001", 17, "Sa");
        servicio3.setCliente(cliente1);        
        System.out.println(servicio3.reportarPago());        
    }
    
}
