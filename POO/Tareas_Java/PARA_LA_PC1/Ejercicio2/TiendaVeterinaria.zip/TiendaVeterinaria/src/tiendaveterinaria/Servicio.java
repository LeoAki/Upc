
package tiendaveterinaria;

public class Servicio {    
    private String codigo;    
    private int hora; //entre 8 y 18
    private String diasemana; //puede ser Lu, Ma, Mi...
    private Cliente cliente;
    
    public Servicio(String codigo, int hora, String diasemana){
        this.codigo = codigo;        
        this.hora = hora;
        this.diasemana = diasemana;
    }
    
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
            
    public String reportarPago(){
        String mensaje = "\n";
        double total  = calcularCostoServicio();
        mensaje += cliente.imprimirCliente();
        mensaje += " debe pagar: ";
        mensaje += total;
        mensaje += " soles, por el baño de ";
        mensaje += cliente.getMascota().getNombre();
        mensaje += "\nServicio prestado el " + diasemana;
        mensaje += " a las " + hora + " horas.";
        return mensaje;
    }       
    
    public double calcularCostoServicio(){           
      double porcentaje_recargo = 0.0;
      double porcentaje_descuento = 0.0;
      char tamanho = this.cliente.getMascota().getTamanho();
          
      switch(tamanho){
          case 'p': 
              porcentaje_recargo = 0.0;
              break;
          case 'm':
              porcentaje_recargo = 0.20;
              break;
          case 'g':
              porcentaje_recargo = 0.40;
              break;              
      }      
      
      if (diasemana.equals("Lu") || diasemana.equals("Ma") || diasemana.equals("Mi")){
          if (hora >= 8 && hora <= 13){
              porcentaje_descuento = 0.10;
          }
      }
          
      return 30 + (30 * porcentaje_recargo) - (30 * porcentaje_descuento);
    }    
    
}
