
package tiendaveterinaria;

public class Mascota {
    private String nombre;
    private String tipo;
    private char tamanho;

    public Mascota(String nombre, String tipo, char tamanho) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.tamanho = tamanho;
    }

    public String getNombre() {
        return nombre;
    }

    public char getTamanho() {
        return tamanho;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTamanho(char tamanho) {
        this.tamanho = tamanho;
    }
    
    
    
}
