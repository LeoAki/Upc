package tiendaveterinaria;

import org.junit.Test;
import static org.junit.Assert.*;

public class ServicioTest {

    /*
    public ServicioTest() {
    }

    @Test
    public void testSetCliente() {
    }

    @Test
    public void testReportarPago() {
    }
    */
    @Test
    public void testCalcularCostoServicio() {
        Mascota mascota1 = new Mascota("Fido", "Perro", 'm');
        Cliente cliente1 = new Cliente("12345678", "Juan", "Perez");
        cliente1.setMascota(mascota1);
        Servicio servicio1 = new Servicio("LU0001", 9, "Lu");
        servicio1.setCliente(cliente1);
        double costo = servicio1.calcularCostoServicio();
        assertEquals(33.0, costo, 0.00);        
    }
    
}
