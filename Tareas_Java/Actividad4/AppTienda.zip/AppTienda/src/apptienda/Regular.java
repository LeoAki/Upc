package apptienda;

public class Regular extends Cliente{
    public Regular(String dni, String nombreApellido){
        super(dni, nombreApellido);
    }

    @Override
    public double calcularFEC() {
        return 0.2;
    }
}
