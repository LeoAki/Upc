package apptienda;

public class Elite extends Cliente{
    private int numeroAutos;
    
    public Elite(String dni, String nombreApellido, int numeroAutos){
        super(dni, nombreApellido);
        this.numeroAutos = numeroAutos;
    }
    
    @Override
    public double calcularFEC() {
        return 0.9 * ((numeroAutos + 1.0) / (numeroAutos));
    }
    
    public int getNumeroAutos() {
        return numeroAutos;
    }

    public void setNumeroAutos(int numeroAutos) {
        this.numeroAutos = numeroAutos;
    }
}
