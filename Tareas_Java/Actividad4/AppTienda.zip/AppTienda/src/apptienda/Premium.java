package apptienda;

public class Premium extends Cliente{
    private int numeroVisitas;
    
    public Premium(String dni, String nombreApellido, int numeroVisitas){
        super(dni, nombreApellido);
        this.numeroVisitas = numeroVisitas;
    }

    @Override
    public double calcularFEC() {
        return 0.5 * ((numeroVisitas) / (numeroVisitas + 1.0));
    }

    public int getNumeroVisitas() {
        return numeroVisitas;
    }

    public void setNumeroVisitas(int numeroVisitas) {
        this.numeroVisitas = numeroVisitas;
    }
}
