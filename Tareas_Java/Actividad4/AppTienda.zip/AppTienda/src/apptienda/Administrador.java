package apptienda;

import java.util.ArrayList;
import java.util.List;

public class Administrador {
    private List<Cliente> clientes;
    
    public Administrador(){
        clientes = new ArrayList<Cliente>();
    }
    
    public String agregarCliente(Cliente cliente){
        if (existeCliente(cliente)){
            //valida si cliente ya existe en Array
            return "Cliente ya existe en base.";
        }
        else{
            clientes.add(cliente);
            return "Cliente " + cliente.nombreApellido + " agegado a base.";
        }
    }
    
    public boolean existeCliente(Cliente cliente){
        boolean existe = false;
        for(Cliente c:clientes){
            if(c.getDni().equals(cliente.dni))
                existe = true;            
        }
        return existe;
    }
    
    public double consultaFteCliente(String dni){
        double fte = 0;
        for(Cliente c:clientes){
            if(c.getDni().equals(dni))
                fte = c.calcularFEC();
        }
        return fte; //es cero si no se encuentra
    }
    
    public int calcularCantidadClientes(){
        return clientes.size();
        //retorna la cantidad de clientes que tiene el ArrayList
    }
    
    public double calcularFteTotal(){
        double fteTotal = 0;
        for(Cliente c:clientes){
            fteTotal += c.calcularFEC();
        }
        return fteTotal;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }
    
    
    
    
    
}
