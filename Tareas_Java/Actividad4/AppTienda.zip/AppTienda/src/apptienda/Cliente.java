package apptienda;

public abstract class Cliente {
    protected String dni;
    protected String nombreApellido;
    
    public Cliente(String dni, String nombreApellido){
        this.dni = dni;
        this.nombreApellido = nombreApellido;
    }
    
    public abstract double calcularFEC();

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }
}
