/*
Ejercicio para la PC2 
 */
package apptienda;

public class AppTienda {
    
    public static void main(String[] args) {
        Administrador administrador = new Administrador();
        
        //Pregunta 1: Se crean 5 clientes de diferentes tipo
        Cliente cliente1 = new Elite("12345678", "Juan Perez", 3);
        Cliente cliente2 = new Elite("24682468", "Miguel Fernandez", 1);
        Cliente cliente3 = new Premium("13571357", "Manuel Rodriguez", 2);
        Cliente cliente4 = new Premium("86428642", "Jorge Benitez", 4);
        Cliente cliente5 = new Regular("12341234", "Andres Reyes");
        
        System.out.println("Registro de Clientes:");
        System.out.println(administrador.agregarCliente(cliente1));
        System.out.println(administrador.agregarCliente(cliente2));
        System.out.println(administrador.agregarCliente(cliente3));
        System.out.println(administrador.agregarCliente(cliente4));
        System.out.println(administrador.agregarCliente(cliente5));
        
        //Pregunta 2
        System.out.println("\nFactor de Evaluación Crediticia por Cliente:");
        System.out.println(administrador.consultaFteCliente(cliente1.dni));
        System.out.println(administrador.consultaFteCliente(cliente2.dni));
        System.out.println(administrador.consultaFteCliente(cliente3.dni));
        System.out.println(administrador.consultaFteCliente(cliente4.dni));
        System.out.println(administrador.consultaFteCliente(cliente5.dni));
        
        System.out.println("\nSuma de Factores de Evaluación Crediticia:");
        System.out.println(administrador.calcularFteTotal());
        
        //Pregunta 3
        System.out.println("\nCantidad de clientes registrados:");
        System.out.println(administrador.calcularCantidadClientes());
        
        //Pregunta4
        System.out.println("\nFactor de evaluación crediticia para cliente con: ");
        System.out.println("DNI 12345678: " + administrador.consultaFteCliente("12345678"));
        System.out.println("DNI 13571357: " + administrador.consultaFteCliente("13571357"));
                
    }
    
}
