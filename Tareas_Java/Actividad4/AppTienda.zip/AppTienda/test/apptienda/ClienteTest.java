package apptienda;

import org.junit.Test;
import static org.junit.Assert.*;
import apptienda.*;

public class ClienteTest {
    
    Administrador administrador = new Administrador();
    //Se crean 3 clientes de diferentes tipo
    Cliente cliente1 = new Elite("12345678", "Juan Perez", 3);    
    Cliente cliente2 = new Premium("13571357", "Manuel Rodriguez", 2);
    Cliente cliente3 = new Regular("12341234", "Andres Reyes");
    
    
        
    public ClienteTest() {
    }

    @Test
    public void testCalcularFteElite() {
        double valorEsperado, valorActual;
        administrador.agregarCliente(cliente1);
        //tiene tres autos
        valorEsperado = 0.9 * ((3 + 1.0) / (3));
        valorActual = cliente1.calcularFEC();
        assertEquals(valorEsperado, valorActual, 0.00);
    }
    
    @Test
    public void testCalcularFtePremium() {
        double valorEsperado, valorActual;
        administrador.agregarCliente(cliente2);
        //tiene dos visitas
        valorEsperado = 0.5 * ((2) / (2 + 1.0));
        valorActual = cliente2.calcularFEC();
        assertEquals(valorEsperado, valorActual, 0.00);
    }
    
    @Test
    public void testCalcularFteRegular() {
        double valorEsperado, valorActual;
        administrador.agregarCliente(cliente3);
        valorEsperado = 0.2;
        valorActual = cliente3.calcularFEC();
        assertEquals(valorEsperado, valorActual, 0.00);
    }   
    
}
